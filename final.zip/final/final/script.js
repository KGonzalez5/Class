
let gitHubRequest = new
XMLHttpRequest();
gitHubRequest.onreadystatechange = function () {
  if (this.readyState == 4 &&
  this.status == 200) {
    let gitObject = JSON.parse
    (this.responseText);
    document.getElementById
    ("gitBio").innerHTML = 
    gitBjest.bio;
  }
}
gitHubRequest.open("GET","https://api.github.com/users/KGonzalez5", true)
gitHubRequest.send();
